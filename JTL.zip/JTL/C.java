class College{
	
}

