class Pragya2024{

 static void P(){
 	clrscr();
 	System.out.println("*********");
 	System.out.println("**********");
 	System.out.println("**        *");
 	System.out.println("**         *");
	System.out.println("**        *");
 	System.out.println("*********");
 	System.out.println("********");
 	System.out.println("**");
 	System.out.println("**");
 	System.out.println("**");
 	System.out.println("**");
 	System.out.println("**");
 	System.out.println("**"); 
 }

static void R(){
 	clrscr();
 	System.out.println("*********");
 	System.out.println("**********");
 	System.out.println("**        *");
 	System.out.println("**         *");
	System.out.println("**        *");
 	System.out.println("*********");
 	System.out.println("********");
 	System.out.println("**");
 	System.out.println("** **");
 	System.out.println("**    **");
 	System.out.println("**       **");
 	System.out.println("**         ** ");
 	System.out.println("**           **"); 
 }
 
 static void A(){
  	clrscr();
 	System.out.println("**********");
 	System.out.println("**********");
 	System.out.println("**      **");
 	System.out.println("**      **");
	System.out.println("**      **");
 	System.out.println("**********");
 	System.out.println("**********");
 	System.out.println("**      **");
 	System.out.println("**      **");
 	System.out.println("**      **");
 	System.out.println("**      **");
 	System.out.println("**      **");
 	System.out.println("**      **"); 
 }

static void G(){
 	clrscr();
 	System.out.println("    ********      ");
 	System.out.println("   ***********    ");
 	System.out.println("  **         **   ");
 	System.out.println(" **               ");
	System.out.println("**                ");
 	System.out.println("**                ");
 	System.out.println("**         *******");
 	System.out.println(" **        *******");
 	System.out.println(" **           **  ");
 	System.out.println("  **         **   ");
 	System.out.println("   **       **    ");
 	System.out.println("    **     **     ");
 	System.out.println("     *******      "); 
 }
 
 
  static void Y(){
   	clrscr();
 	System.out.println("**      **");
 	System.out.println("**      **");
 	System.out.println("**      **");
 	System.out.println("**      **");
	System.out.println("**      **");
 	System.out.println("**********");
 	System.out.println("**********");
 	System.out.println("   ***    ");
 	System.out.println("   ***    ");
 	System.out.println("   ***    ");
 	System.out.println("   ***    ");
 	System.out.println("   ***    ");
 	System.out.println("   ***    ");
 }
 
 
 static void _2(){
  	clrscr();
 	System.out.println(" **********    ");
 	System.out.println("***********    ");
 	System.out.println("**       **    ");
 	System.out.println("        **     ");
	System.out.println("       **      ");
 	System.out.println("      **       ");
 	System.out.println("     **        ");
 	System.out.println("    **         ");
 	System.out.println("   **          ");
 	System.out.println("  **           ");
 	System.out.println(" **            ");
 	System.out.println(" ***********   ");
 	System.out.println(" ***********   "); 
 }
 
 
static void _0(){
 	clrscr();
 	System.out.println("************");
 	System.out.println("************ ");
 	System.out.println("**        ** ");
 	System.out.println("**        ** ");
	System.out.println("**        ** ");
 	System.out.println("**        ** ");
 	System.out.println("**        ** ");
 	System.out.println("**        ** ");
 	System.out.println("**        ** ");
 	System.out.println("**        ** ");
 	System.out.println("**        ** ");
 	System.out.println("************ ");
 	System.out.println("************ "); 
 }
 
 static void _4(){
  	clrscr();
 	System.out.println("**      **");
 	System.out.println("**      **");
 	System.out.println("**      **");
 	System.out.println("**      **");
	System.out.println("**      **");
 	System.out.println("**********");
 	System.out.println("**********");
 	System.out.println("        **");
 	System.out.println("        **");
 	System.out.println("        **");
 	System.out.println("        **");
 	System.out.println("        **");
 	System.out.println("        **"); 
 }
 
 	public static void main(String args[]){
 	P();R();A();G();Y();A();
 	_2();_0();_2();_4();
 	
 	}

 static void clrscr(){
 	try{
		Thread.sleep(1000);
	   }
	   catch(Exception pragya){
	   
	   }
 	System.out.println("\033[H\033[2J"); 
 } 
}

