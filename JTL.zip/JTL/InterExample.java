interface InterfaceSample {
	void fun();
}
