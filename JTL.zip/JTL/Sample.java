class Sample{
	abstract void funSampleAbstract();	
	void fun(){
	}
}

